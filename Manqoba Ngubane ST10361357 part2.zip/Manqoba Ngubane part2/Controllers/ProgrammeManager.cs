﻿using Microsoft.AspNetCore.Mvc;

namespace Thabelop2.Controllers
{
    public class ProgrammeManager : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
