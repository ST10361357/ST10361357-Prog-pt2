﻿namespace Thabelop2
{
    public class connection
    {
        //return connection string method
        public string connecting()
        {
            //then return the connection
            return "Data Source=(localdb)\\Thabelop2;Initial Catalog=CLAIMSDB;";
        }

    }
}
